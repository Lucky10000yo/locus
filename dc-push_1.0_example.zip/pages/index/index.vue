<template>
	<view class="content">
		<image class="logo" src="/static/logo.png"></image>
		<view class="text-area">
			<text class="title">{{title}}</text>
		</view>
		<view class="uni-list">
			<view class="uni-list-cell uni-list-cell-pd">
				<view class="uni-list-cell-db">推送通知</view>
				<switch :checked="isPushOn" @change="pushChange" />
			</view>
		</view>
	</view>
</template>

<script>
// #ifdef APP-PLUS
	import push from "@/common/dc-push/push.js"
// #endif
	export default {
		data() {
			return {
				title: '未知状态',
				isPushOn: false
			}
		},
		onLoad() {
		},
		onShow() {
			this.updatePush();
			console.log('updatePush @ onShow');
		},
		methods: {
			pushChange(e){
				this.isPushOn = e.detail.value;
				if(this.isPushOn){
// #ifdef APP-PLUS
					push.on();
// #endif
				}else{
// #ifdef APP-PLUS
					push.off();
// #endif
				}
				this.title = this.isPushOn?'已开启':'已关闭';
			},
			updatePush(){
// #ifdef APP-PLUS
				this.isPushOn = push.isOn();
// #endif
				this.title = this.isPushOn?'已开启':'已关闭';
			}
		}
	}
</script>

<style>
	button {
		margin-top: 30upx;
		margin-bottom: 30upx;
	}
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}
	.logo {
		height: 200upx;
		width: 200upx;
		margin-top: 100upx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50upx;
	}
	.text-area {
		display: flex;
		justify-content: center;
	}
	.title {
		font-size: 32upx;
		color: #8f8f94;
	}
	.section {
		margin-top: 50upx;
		width: 60%;
		text-align: center;
	}
	.tips {
		font-size: 26upx;
		color: #DD524D;
	}
	.uni-list {
		background-color: #FFFFFF;
		position: relative;
		width: 100%;
		display: flex;
		flex-direction: column;
	}
	.uni-list-cell {
		position: relative;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
	}
	.uni-list-cell-pd {
		padding: 22upx 30upx;
	}
	.uni-list-cell-db {
		flex: 1;
	}
</style>
